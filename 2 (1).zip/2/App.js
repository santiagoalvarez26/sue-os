import React, { useState } from 'react';
import {
  SafeAreaView,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Platform,
  FlatList
} from 'react-native';

export default function App() {
  const [dream, setDream] = useState('');
  const [dreams, setDreams] = useState([]);

  const handleSaveDream = () => {
    if (dream.trim() === '') return;
    const newDream = { id: Date.now().toString(), text: dream.trim() };
    setDreams([newDream, ...dreams]);
    setDream('');
  };

  const handleDeleteDream = (id) => {
    setDreams(dreams.filter(d => d.id !== id));
  };

  const renderItem = ({ item }) => (
    <View style={styles.dreamItem}>
      <Text style={styles.dreamText}>{item.text}</Text>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDeleteDream(item.id)}
      >
        <Text style={styles.deleteButtonText}>Eliminar</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="always"
        >
          <View style={styles.container}>
            <Text style={styles.title}>Diario de Sueños</Text>
            <View style={styles.inputContainer}>
              <TextInput
                placeholder="Escribe tu sueño aquí..."
                placeholderTextColor="#999"
                value={dream}
                onChangeText={setDream}
                multiline
                style={styles.textarea}
              />
              <TouchableOpacity style={styles.button} onPress={handleSaveDream}>
                <Text style={styles.buttonText}>Guardar Sueño</Text>
              </TouchableOpacity>
            </View>
            {dreams.length === 0 ? (
              <Text style={styles.infoText}>
                No hay sueños guardados. ¡Empieza a escribir!
              </Text>
            ) : (
              <FlatList
                data={dreams}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                style={styles.dreamList}
              />
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f6d365',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 10,
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
    width: '100%',
    maxWidth: 420,
    alignSelf: 'center',
    marginTop: 40,
    marginBottom: 20,
  },
  title: {
    textAlign: 'center',
    color: '#333',
    marginBottom: 15,
    fontSize: 24,
    fontWeight: 'bold',
  },
  inputContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  textarea: {
    width: '100%',
    minHeight: 80,
    padding: 8,
    fontSize: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
    textAlign: 'center',
    color: '#333',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#28a745',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    width: '100%',
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
  infoText: {
    textAlign: 'center',
    color: '#555',
    fontSize: 14,
    padding: 10,
  },
  dreamList: {
    marginTop: 15,
  },
  dreamItem: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dreamText: {
    color: '#333',
    fontSize: 14,
    flex: 1,
    marginRight: 10,
  },
  deleteButton: {
    backgroundColor: '#dc3545',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  deleteButtonText: {
    color: '#fff',
    fontSize: 12,
  },
});
